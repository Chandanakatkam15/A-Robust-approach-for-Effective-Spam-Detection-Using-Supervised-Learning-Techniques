# sms spam classifier
I have used an naive bayes model along with natural language processing to create this model


Porter Stemmer, Bag of words are the nlp techniques used for text preprocessing
This model will be able to classify a message as spam or ham with an accuracy of 92 percent

The machine learning algorithm used here is MultinomialNB which uses bayes theorem from probability

